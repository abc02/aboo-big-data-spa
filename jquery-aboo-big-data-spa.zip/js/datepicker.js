$('.datepicker').datepicker({
  format: 'yyyy-mm-dd',
  language: "zh-CN"
});